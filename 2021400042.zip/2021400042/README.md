# DB_File_Organization
page and record optimization for Database Management/ CMPE321 Project 4

** How to run the code 

Under the folder where the archive.py exists (same folder that is submitted as a zip)

Run 

> python3 archive.py input_file_path

* log.txt and output.txt file will be created in the same folder with archive.py 


